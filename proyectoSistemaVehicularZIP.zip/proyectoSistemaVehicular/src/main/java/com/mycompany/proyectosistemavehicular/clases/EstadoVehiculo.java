
package com.mycompany.proyectosistemavehicular.clases;

/**
 *
 * @author vcarl
 */
public enum EstadoVehiculo {
    DISPONIBLE,
    EN_USO
}